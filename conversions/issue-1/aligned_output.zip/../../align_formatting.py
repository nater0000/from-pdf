import os
import random
import sys
import time
from pathlib import Path
from google import genai
from google.genai import errors

def call_gemini_with_backoff(client, model, prompt, max_retries=6, base_delay=5):
    delay = base_delay
    for attempt in range(1, max_retries + 1):
        try:
            print(f"-> Sending alignment request to {model} (Attempt {attempt}/{max_retries})...")
            response = client.models.generate_content(
                model=model,
                contents=prompt
            )
            return response.text
        except (errors.ServerError, errors.APIError) as e:
            if attempt == max_retries:
                print(f"❌ Exhausted all {max_retries} attempts. Final Error: {e}")
                raise e
            
            jitter = random.uniform(0.5, 2.0)
            wait_time = delay + jitter
            print(f"⚠️ Model temporary error: {e}. Retrying in {wait_time:.1f}s...")
            time.sleep(wait_time)
            delay *= 2

def fuzzy_llm_merge(corrupted_path, clean_path, output_path):
    print(f"-> Loading corrupted formatted text: {corrupted_path}")
    with open(corrupted_path, 'r', encoding='utf-8') as f:
        corr_text = f.read()
        
    print(f"-> Loading clean OCR text: {clean_path}")
    with open(clean_path, 'r', encoding='utf-8') as f:
        clean_text = f.read()
        
    client = genai.Client()
    
    prompt = f"""You are a precise fuzzy-matching text alignment engine. 
You will receive two versions of a document. 
1. CORRUPTED TEXT: Contains correct markdown formatting (**bold**, *italics*, etc.) but broken character spacing.
2. CLEAN OCR TEXT: Has perfect spelling and natural spacing, but lacks formatting.

Task: Map the markdown formatting tags from the CORRUPTED text onto the CLEAN OCR text. 
The CLEAN OCR TEXT is the absolute source of truth for spelling, line breaks, and spaces. 
Do not summarize or alter the clean text; only inject the formatting tags into their correct positions.

--- CORRUPTED TEXT ---
{corr_text}

--- CLEAN OCR TEXT ---
{clean_text}
"""
    
    aligned_text = call_gemini_with_backoff(
        client=client,
        model='gemini-3.6-flash',
        prompt=prompt
    )
    
    print(f"-> Saving aligned markdown to: {output_path}")
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(aligned_text)

if __name__ == "__main__":
    issue_num = sys.argv[1]
    corrupted_md = Path(f"conversions/issue-{issue_num}/corrupted/document/document.md")
    clean_md = Path(f"conversions/issue-{issue_num}/fixed/document/document.md")
    output_md = Path(f"conversions/issue-{issue_num}/document_aligned.md")
    
    if corrupted_md.exists() and clean_md.exists():
        fuzzy_llm_merge(corrupted_md, clean_md, output_md)
        print("✅ Dual-input alignment complete.")
    else:
        print("❌ Missing input files. Alignment aborted.")
        sys.exit(1)
