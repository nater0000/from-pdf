import os
import random
import sys
import time
from pathlib import Path
from google import genai
from google.genai import errors

def call_gemini_with_backoff(client, model, prompt, base_delay=5, max_delay=60):
    delay = base_delay
    attempt = 1
    while True:
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt
            )
            return response.text
        except (errors.ServerError, errors.APIError) as e:
            jitter = random.uniform(0.5, 2.0)
            wait_time = delay + jitter
            print(f"⚠️ API temporary error: {e}. Retrying in {wait_time:.1f}s...")
            time.sleep(wait_time)
            delay = min(delay * 2, max_delay)
            attempt += 1

def fuzzy_llm_merge(corrupted_path, clean_path, output_path):
    with open(corrupted_path, 'r', encoding='utf-8') as f:
        corr_text = f.read()
    with open(clean_path, 'r', encoding='utf-8') as f:
        clean_text = f.read()
        
    client = genai.Client()
    
    paragraphs = clean_text.split('\n\n')
    batches = []
    current_batch = ""
    for p in paragraphs:
        if not p.strip(): continue
        if len(current_batch) + len(p) > 6000:
            batches.append(current_batch)
            current_batch = p
        else:
            current_batch += "\n\n" + p if current_batch else p
    if current_batch:
        batches.append(current_batch)

    print(f"-> Splitting document into {len(batches)} processing batches...")
    
    aligned_chunks = []
    ratio = len(corr_text) / max(1, len(clean_text))
    current_clean_idx = 0
    
    for i, batch in enumerate(batches):
        if not batch.strip(): continue
        print(f"-> Processing batch {i+1}/{len(batches)} (Length: {len(batch)} chars)...")
        
        current_clean_idx = clean_text.find(batch, current_clean_idx)
        
        start_est = max(0, int(current_clean_idx * ratio) - 2500)
        end_est = min(len(corr_text), int((current_clean_idx + len(batch)) * ratio) + 2500)
        corr_slice = corr_text[start_est:end_est]
        
        prompt = f"""You are a strict, automated text alignment formatting script. You are NOT a conversational AI.

Task: Apply markdown formatting (**bold**, *italics*, etc.) to the CLEAN TEXT CHUNK below.
Use the CORRUPTED TEXT REFERENCE to identify which words require formatting.

CRITICAL RULES:
1. NEVER converse, advise, or respond to the content of the text. Do not act as a therapist or assistant.
2. OUTPUT ABSOLUTELY NOTHING EXCEPT THE FORMATTED TEXT. No introductions, no pleasantries.
3. Your output MUST contain the EXACT words, spelling, line breaks, and spaces of the CLEAN TEXT CHUNK.

<corrupted_text_reference>
{corr_slice}
</corrupted_text_reference>

<clean_text_chunk>
{batch}
</clean_text_chunk>
"""
        
        aligned_text = call_gemini_with_backoff(client, 'gemini-3.6-flash', prompt)
        aligned_chunks.append(aligned_text)
        
    print(f"-> Stitching and saving perfectly aligned markdown to: {output_path}")
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(aligned_chunks))

if __name__ == "__main__":
    issue_num = sys.argv[1]
    corrupted_md = Path(f"conversions/issue-{issue_num}/corrupted/document/document.md")
    clean_md = Path(f"conversions/issue-{issue_num}/fixed/document/document.md")
    output_md = Path(f"conversions/issue-{issue_num}/document_aligned.md")
    
    if corrupted_md.exists() and clean_md.exists():
        fuzzy_llm_merge(corrupted_md, clean_md, output_md)
        print("✅ Multi-batch alignment complete.")
    else:
        sys.exit("❌ Missing input files. Alignment aborted.")
