import os
import random
import sys
import time
import re
from pathlib import Path
from google import genai

def heuristic_cleanup(text):
    text = text.replace('**', '∆∆').replace('*', '∆')
    chunks = re.split(r'( {2,}|\n+)', text)
    cleaned_chunks = []
    for chunk in chunks:
        if chunk.isspace():
            cleaned_chunks.append(chunk) 
        else:
            cleaned_chunk = re.sub(r'(?<=\S) (?=\S)', '', chunk)
            cleaned_chunks.append(cleaned_chunk)
    final_text = ''.join(cleaned_chunks)
    final_text = final_text.replace('∆∆', '**').replace('∆', '*')
    return final_text

def call_gemini_with_backoff(client, model, prompt, base_delay=5, max_delay=60, max_retries=30):
    delay = base_delay
    attempt = 1
    while True:
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt
            )
            return response.text
        except Exception as e:
            if attempt >= max_retries:
                print(f"\n❌ FATAL: Max retries ({max_retries}) reached.", flush=True)
                sys.exit(1)
            error_str = str(e)
            if '429' in error_str or 'RESOURCE_EXHAUSTED' in error_str:
                match = re.search(r'retry in ([\d\.]+)s', error_str, re.IGNORECASE)
                wait_time = float(match.group(1)) + 2.0 if match else 65.0
                print(f"🛑 Rate limit hit. Pausing {wait_time}s...", flush=True)
                time.sleep(wait_time)
                attempt += 1
                continue

            jitter = random.uniform(0.5, 2.0)
            wait_time = delay + jitter
            print(f"⚠️ API temporary error: {e}. Retrying in {wait_time:.1f}s...", flush=True)
            time.sleep(wait_time)
            delay = min(delay * 2, max_delay)
            attempt += 1

def fuzzy_llm_merge(corrupted_path, clean_path, output_path):
    with open(corrupted_path, 'r', encoding='utf-8') as f:
        corr_text = f.read()
    with open(clean_path, 'r', encoding='utf-8') as f:
        clean_text = f.read()
        
    client = genai.Client()
    paragraphs = clean_text.split('\n\n')
    batches = []
    current_batch = ""
    for p in paragraphs:
        if not p.strip(): continue
        if len(current_batch) + len(p) > 6000:
            batches.append(current_batch)
            current_batch = p
        else:
            current_batch += "\n\n" + p if current_batch else p
    if current_batch:
        batches.append(current_batch)

    aligned_chunks = []
    ratio = len(corr_text) / max(1, len(clean_text))
    current_clean_idx = 0
    
    for i, batch in enumerate(batches):
        if not batch.strip(): continue
        print(f"-> Processing batch {i+1}/{len(batches)} (Length: {len(batch)} chars)...", flush=True)
        
        current_clean_idx = clean_text.find(batch, current_clean_idx)
        start_est = max(0, int(current_clean_idx * ratio) - 2500)
        end_est = min(len(corr_text), int((current_clean_idx + len(batch)) * ratio) + 2500)
        corr_slice = corr_text[start_est:end_est]
        heuristic_slice = heuristic_cleanup(corr_slice)
        
        # ==========================================
        # PASS 1: The Linear Baseline
        # ==========================================
        prompt_pass1 = f"""You are a strict, highly accurate Markdown formatter.
TASK: Apply formatting (**bold**, *italics*) to the CLEAN OCR TEXT based on the visual hints in the REFERENCES.

CRITICAL RULES:
1. NO TABLES ALLOWED: You are strictly forbidden from creating Markdown tables (`|---|`). Format everything linearly using normal paragraphs, headings (`###`), and bullet points (`-`).
2. ZERO DELETION: You must include 100% of the words from the CLEAN OCR TEXT. Do not drop footers, contact information, timestamps, or partial sentences. Process the text exactly from top to bottom.
3. MATHEMATICS: Convert pseudo-LaTeX or broken math into standard LaTeX equations ($...$ or $$...$$).
4. Output your formatted text inside <linear_markdown> tags.

<raw_corrupted_reference>
{corr_slice}
</raw_corrupted_reference>

<heuristic_reference>
{heuristic_slice}
</heuristic_reference>

<clean_ocr_text>
{batch}
</clean_ocr_text>
"""
        print("   [Pass 1] Generating linear markdown (100% text retention)...", flush=True)
        pass1_text = call_gemini_with_backoff(client, 'gemini-3.5-flash-lite', prompt_pass1)
        
        match_1 = re.search(r'<linear_markdown>(.*?)</linear_markdown>', pass1_text, re.DOTALL | re.IGNORECASE)
        linear_md = match_1.group(1).strip() if match_1 else pass1_text.replace('```markdown', '').replace('```', '').strip()
        
        # ==========================================
        # PASS 2: The Table Upgrader
        # ==========================================
        prompt_pass2 = f"""You are a layout structural editor.
TASK: Take the LINEAR MARKDOWN below and upgrade specific lists/schedules into Markdown tables IF they logically belong in a two-column format (like steps mapping to timestamps).

CRITICAL RULES:
1. ONLY modify the specific lines that are being turned into a table.
2. Use standard Markdown tables (`|---|`) and use `<br>` for line breaks inside cells.
3. STRICT TEXT RETENTION: You must perfectly preserve all text BEFORE and AFTER the table. Do not delete or move intros, paragraphs, footers, or contact info. If you break a sentence to insert a table, you have failed.
4. If the text does not contain tabular data, output the exact same text without changes.
5. Output your final text inside <final_markdown> tags.

<linear_markdown>
{linear_md}
</linear_markdown>
"""
        print("   [Pass 2] Upgrading layout to tables where appropriate...", flush=True)
        pass2_text = call_gemini_with_backoff(client, 'gemini-3.5-flash-lite', prompt_pass2)
        
        match_2 = re.search(r'<final_markdown>(.*?)</final_markdown>', pass2_text, re.DOTALL | re.IGNORECASE)
        final_aligned = match_2.group(1).strip() if match_2 else pass2_text.replace('```markdown', '').replace('```', '').strip()

        aligned_chunks.append(final_aligned)
        time.sleep(10)
        
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(aligned_chunks))

if __name__ == "__main__":
    issue_num = sys.argv[1]
    corrupted_md = Path(f"conversions/issue-{issue_num}/corrupted/document/document.md")
    clean_md = Path(f"conversions/issue-{issue_num}/fixed/document/document.md")
    output_md = Path(f"conversions/issue-{issue_num}/document_aligned.md")
    if corrupted_md.exists() and clean_md.exists():
        fuzzy_llm_merge(corrupted_md, clean_md, output_md)
    else:
        sys.exit("❌ Missing input files.")
