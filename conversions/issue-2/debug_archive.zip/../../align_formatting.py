import os
import random
import sys
import time
import re
from pathlib import Path
from google import genai
from google.genai import errors

def heuristic_cleanup(text):
    text = text.replace('**', '∆∆').replace('*', '∆')
    chunks = re.split(r'( {2,}|\n+)', text)
    cleaned_chunks = []
    for chunk in chunks:
        if chunk.isspace():
            cleaned_chunks.append(chunk) 
        else:
            cleaned_chunk = re.sub(r'(?<=\S) (?=\S)', '', chunk)
            cleaned_chunks.append(cleaned_chunk)
    final_text = ''.join(cleaned_chunks)
    final_text = final_text.replace('∆∆', '**').replace('∆', '*')
    return final_text

def call_gemini_with_backoff(client, model, prompt, base_delay=5, max_delay=60, max_retries=30):
    delay = base_delay
    attempt = 1
    while True:
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt
            )
            return response.text
        except Exception as e:
            if attempt >= max_retries:
                print(f"\n❌ FATAL: Max retries ({max_retries}) reached. The API is permanently blocking the request (Quota exhausted).", flush=True)
                sys.exit(1)
                
            error_str = str(e)
            
            # Smart Intercept for 429 RPM Quota Exhaustion
            if '429' in error_str or 'RESOURCE_EXHAUSTED' in error_str:
                match = re.search(r'retry in ([\d\.]+)s', error_str, re.IGNORECASE)
                if match:
                    # Use exactly what the API asks for + a 2-second safety buffer
                    wait_time = float(match.group(1)) + 2.0
                    print(f"🛑 Rate limit hit (Attempt {attempt}/{max_retries}). Pausing exactly {wait_time:.1f}s as requested by API...", flush=True)
                else:
                    wait_time = 65.0
                    print(f"🛑 Rate limit hit (Attempt {attempt}/{max_retries}). Pausing {wait_time}s...", flush=True)
                
                time.sleep(wait_time)
                attempt += 1
                continue

            # Fallback for standard 500/503 temporary server errors
            jitter = random.uniform(0.5, 2.0)
            wait_time = delay + jitter
            print(f"⚠️ API temporary error (Attempt {attempt}/{max_retries}): {e}. Retrying in {wait_time:.1f}s...", flush=True)
            time.sleep(wait_time)
            delay = min(delay * 2, max_delay)
            attempt += 1

def fuzzy_llm_merge(corrupted_path, clean_path, output_path):
    with open(corrupted_path, 'r', encoding='utf-8') as f:
        corr_text = f.read()
    with open(clean_path, 'r', encoding='utf-8') as f:
        clean_text = f.read()
        
    client = genai.Client()
    
    paragraphs = clean_text.split('\n\n')
    batches = []
    current_batch = ""
    for p in paragraphs:
        if not p.strip(): continue
        if len(current_batch) + len(p) > 6000:
            batches.append(current_batch)
            current_batch = p
        else:
            current_batch += "\n\n" + p if current_batch else p
    if current_batch:
        batches.append(current_batch)

    print(f"-> Splitting document into {len(batches)} processing batches...", flush=True)
    
    aligned_chunks = []
    ratio = len(corr_text) / max(1, len(clean_text))
    current_clean_idx = 0
    
    for i, batch in enumerate(batches):
        if not batch.strip(): continue
        print(f"-> Processing batch {i+1}/{len(batches)} (Length: {len(batch)} chars)...", flush=True)
        
        current_clean_idx = clean_text.find(batch, current_clean_idx)
        
        start_est = max(0, int(current_clean_idx * ratio) - 2500)
        end_est = min(len(corr_text), int((current_clean_idx + len(batch)) * ratio) + 2500)
        
        corr_slice = corr_text[start_est:end_est]
        heuristic_slice = heuristic_cleanup(corr_slice)
        
        prompt = f"""You are a strict, automated text alignment parser. You are NOT a conversational AI.
Task: Apply markdown formatting (**bold**, *italics*, etc.) to the CLEAN OCR TEXT below based on the provided references.

CRITICAL RULES:
1. NEVER converse, advise, or respond to the content. Do not act as a therapist.
2. DO NOT format non-alphanumeric markdown syntax. Never inject ** or * inside image tags (like ![]() ) or URLs.
3. Your output MUST perfectly match the EXACT words, spelling, line breaks, and spaces of the CLEAN OCR TEXT, with ONE EXCEPTION:
   - MATHEMATICAL FORMULAS: When you encounter pseudo-LaTeX, ASCII math, or broken equation typography (e.g., `v[...]` or `\vartheta[...]` for square root, `\wedge^2` for squared, `y = 1/v[...]` for the Lorentz factor, `1_p` for `l_p`, `\Sigma_i` for summation, missing brackets, etc.), convert them into clean, valid, standard LaTeX equations ($...$ for inline, $$...$$ for block display).
4. You MUST output your final processed text strictly inside <aligned_text> and </aligned_text> XML tags.

<raw_corrupted_reference>
{corr_slice}
</raw_corrupted_reference>

<heuristic_reference>
{heuristic_slice}
</heuristic_reference>

<clean_ocr_text>
{batch}
</clean_ocr_text>
"""
        
        # Successfully upgraded to the high-throughput Lite model
        aligned_text = call_gemini_with_backoff(client, 'gemini-3.5-flash-lite', prompt)
        
        match = re.search(r'<aligned_text>(.*?)</aligned_text>', aligned_text, re.DOTALL | re.IGNORECASE)
        if match:
            clean_aligned = match.group(1).strip()
        else:
            clean_aligned = aligned_text.replace('```markdown', '').replace('```', '').strip()
            
        aligned_chunks.append(clean_aligned)
        
        # Pacing the API to naturally smooth out Token-Per-Minute quotas
        print("✅ Batch processed successfully. Pacing API...", flush=True)
        time.sleep(10)
        
    print(f"-> Stitching and saving perfectly aligned markdown to: {output_path}", flush=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(aligned_chunks))

if __name__ == "__main__":
    issue_num = sys.argv[1]
    corrupted_md = Path(f"conversions/issue-{issue_num}/corrupted/document/document.md")
    clean_md = Path(f"conversions/issue-{issue_num}/fixed/document/document.md")
    output_md = Path(f"conversions/issue-{issue_num}/document_aligned.md")
    
    if corrupted_md.exists() and clean_md.exists():
        fuzzy_llm_merge(corrupted_md, clean_md, output_md)
        print("✅ Multi-batch alignment complete.", flush=True)
    else:
        sys.exit("❌ Missing input files. Alignment aborted.")
