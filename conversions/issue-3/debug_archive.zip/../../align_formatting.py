import os
import random
import sys
import time
import re
from pathlib import Path
from openai import OpenAI

def heuristic_cleanup(text):
    text = text.replace('**', '∆∆').replace('*', '∆')
    chunks = re.split(r'( {2,}|\n+)', text)
    cleaned_chunks = []
    for chunk in chunks:
        if chunk.isspace():
            cleaned_chunks.append(chunk) 
        else:
            cleaned_chunk = re.sub(r'(?<=\S) (?=\S)', '', chunk)
            cleaned_chunks.append(cleaned_chunk)
    final_text = ''.join(cleaned_chunks)
    final_text = final_text.replace('∆∆', '**').replace('∆', '*')
    return final_text

def clean_for_comparison(text):
    return re.sub(r'[^a-zA-Z0-9]', '', text).lower()

def call_openrouter_with_backoff(client, model, prompt, base_delay=5, max_delay=60, max_retries=30):
    delay = base_delay
    attempt = 1
    while True:
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}]
            )
            return response.choices[0].message.content
        except Exception as e:
            if attempt >= max_retries:
                print(f"\n❌ FATAL: OpenRouter max retries ({max_retries}) reached.", flush=True)
                sys.exit(1)
            error_str = str(e)
            if '429' in error_str or 'RateLimit' in error_str:
                wait_time = 15.0
                print(f"🛑 OpenRouter rate limit hit. Pausing {wait_time}s...", flush=True)
                time.sleep(wait_time)
                attempt += 1
                continue

            jitter = random.uniform(0.5, 2.0)
            wait_time = delay + jitter
            print(f"⚠️ OpenRouter temporary error: {e}. Retrying in {wait_time:.1f}s...", flush=True)
            time.sleep(wait_time)
            delay = min(delay * 2, max_delay)
            attempt += 1

def fuzzy_llm_merge(corrupted_path, clean_path, output_path):
    with open(corrupted_path, 'r', encoding='utf-8') as f:
        corr_text = f.read()
    with open(clean_path, 'r', encoding='utf-8') as f:
        clean_text = f.read()
        
    openrouter_client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=os.environ.get("OPENROUTER_API_KEY")
    )
    
    paragraphs = clean_text.split('\n\n')
    batches = []
    current_batch = ""
    for p in paragraphs:
        if not p.strip(): continue
        if len(current_batch) + len(p) > 6000:
            batches.append(current_batch)
            current_batch = p
        else:
            current_batch += "\n\n" + p if current_batch else p
    if current_batch:
        batches.append(current_batch)

    aligned_chunks = []
    ratio = len(corr_text) / max(1, len(clean_text))
    current_clean_idx = 0
    
    # Using Nemotron 3 Ultra - incredibly smart 550B model available entirely for free on OpenRouter
    model_name = 'nvidia/nemotron-3-ultra-550b-a55b:free'
    
    for i, batch in enumerate(batches):
        if not batch.strip(): continue
        print(f"-> Processing batch {i+1}/{len(batches)}...", flush=True)
        
        current_clean_idx = clean_text.find(batch, current_clean_idx)
        start_est = max(0, int(current_clean_idx * ratio) - 2500)
        end_est = min(len(corr_text), int((current_clean_idx + len(batch)) * ratio) + 2500)
        corr_slice = corr_text[start_est:end_est]
        heuristic_slice = heuristic_cleanup(corr_slice)
        
        # ==========================================
        # PASS 1: The Linear Baseline
        # ==========================================
        prompt_1 = f"""You are a strict Markdown formatter.
TASK: Apply formatting (**bold**, *italics*) to the CLEAN OCR TEXT based on the visual hints in the REFERENCES.

CRITICAL RULES:
1. ABSOLUTELY NO TABLES: You are strictly forbidden from outputting Markdown tables (`|---|`). Format everything sequentially as standard paragraphs and bullet points (`- `). 
2. ZERO DELETION: You must format 100% of the text. Do not drop trailing footers, contact information, or orphaned sentences. Process the text exactly from top to bottom.
3. Convert pseudo-LaTeX or broken math into standard LaTeX equations ($...$ or $$...$$).
4. Output your formatted text inside <linear_markdown> tags.

<raw_corrupted_reference>
{corr_slice}
</raw_corrupted_reference>

<heuristic_reference>
{heuristic_slice}
</heuristic_reference>

<clean_ocr_text>
{batch}
</clean_ocr_text>
"""
        print(f"   [Pass 1] {model_name}: Generating linear baseline...", flush=True)
        pass1_text = call_openrouter_with_backoff(openrouter_client, model_name, prompt_1)
        match_1 = re.search(r'<linear_markdown>(.*?)</linear_markdown>', pass1_text, re.DOTALL | re.IGNORECASE)
        linear_md = match_1.group(1).strip() if match_1 else pass1_text.replace('```markdown', '').replace('```', '').strip()
        
        time.sleep(4) # Respect OpenRouter 20 RPM limit
        
        # ==========================================
        # PASS 2: The Table Builder
        # ==========================================
        prompt_2 = f"""You are an advanced layout editor.
TASK: Take the LINEAR MARKDOWN below and convert schedules, lists, or mapped data into standard Markdown tables (`|---|`).

CRITICAL RULES:
1. When converting text to table cells, you may ONLY use `<br>` tags for line breaks. Do not use any other HTML.
2. Leave standard paragraphs, footnotes, contact information, and headings outside the table exactly as they are. DO NOT delete any text.
3. Output your text inside <tabular_markdown> tags.

<linear_markdown>
{linear_md}
</linear_markdown>
"""
        print(f"   [Pass 2] {model_name}: Upgrading layout to tables...", flush=True)
        pass2_text = call_openrouter_with_backoff(openrouter_client, model_name, prompt_2)
        match_2 = re.search(r'<tabular_markdown>(.*?)</tabular_markdown>', pass2_text, re.DOTALL | re.IGNORECASE)
        tabular_md = match_2.group(1).strip() if match_2 else pass2_text.replace('```markdown', '').replace('```', '').strip()

        # ==========================================
        # PASS 3: Deterministic Python Reconciliation
        # ==========================================
        print("   [Pass 3] Deterministically checking for dropped orphans...", flush=True)
        
        linear_paragraphs = [p.strip() for p in linear_md.split('\n\n') if p.strip()]
        tab_clean_full = clean_for_comparison(tabular_md)
        
        missing_orphans = []
        for p in linear_paragraphs:
            p_clean = clean_for_comparison(p)
            
            if len(p_clean) < 15: 
                continue
                
            chunk = p_clean[:30] if len(p_clean) >= 30 else p_clean
            
            if chunk not in tab_clean_full:
                missing_orphans.append(p)
                print(f"      [🔍 FOUND MISSING TEXT] Appending: '{p[:50]}...'")

        final_text = tabular_md
        if missing_orphans:
            final_text += "\n\n" + "\n\n".join(missing_orphans)

        aligned_chunks.append(final_text)
        time.sleep(4)
        
    print(f"-> Stitching and saving perfectly aligned markdown to: {output_path}", flush=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(aligned_chunks))

if __name__ == "__main__":
    issue_num = sys.argv[1]
    corrupted_md = Path(f"conversions/issue-{issue_num}/corrupted/document/document.md")
    clean_md = Path(f"conversions/issue-{issue_num}/fixed/document/document.md")
    output_md = Path(f"conversions/issue-{issue_num}/document_aligned.md")
    if corrupted_md.exists() and clean_md.exists():
        fuzzy_llm_merge(corrupted_md, clean_md, output_md)
        print("✅ Multi-batch alignment complete.", flush=True)
    else:
        sys.exit("❌ Missing input files.")
