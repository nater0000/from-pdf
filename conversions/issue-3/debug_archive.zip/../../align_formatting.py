import os
import random
import sys
import time
import re
from pathlib import Path
from google import genai

def heuristic_cleanup(text):
    text = text.replace('**', '∆∆').replace('*', '∆')
    chunks = re.split(r'( {2,}|\n+)', text)
    cleaned_chunks = []
    for chunk in chunks:
        if chunk.isspace():
            cleaned_chunks.append(chunk) 
        else:
            cleaned_chunk = re.sub(r'(?<=\S) (?=\S)', '', chunk)
            cleaned_chunks.append(cleaned_chunk)
    final_text = ''.join(cleaned_chunks)
    final_text = final_text.replace('∆∆', '**').replace('∆', '*')
    return final_text

def call_gemini_with_backoff(client, model, prompt, base_delay=5, max_delay=60, max_retries=30):
    delay = base_delay
    attempt = 1
    while True:
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt
            )
            return response.text
        except Exception as e:
            if attempt >= max_retries:
                print(f"\n❌ FATAL: Max retries ({max_retries}) reached.", flush=True)
                sys.exit(1)
            error_str = str(e)
            if '429' in error_str or 'RESOURCE_EXHAUSTED' in error_str:
                match = re.search(r'retry in ([\d\.]+)s', error_str, re.IGNORECASE)
                wait_time = float(match.group(1)) + 2.0 if match else 65.0
                print(f"🛑 Rate limit hit. Pausing {wait_time}s...", flush=True)
                time.sleep(wait_time)
                attempt += 1
                continue

            jitter = random.uniform(0.5, 2.0)
            wait_time = delay + jitter
            print(f"⚠️ API temporary error: {e}. Retrying in {wait_time:.1f}s...", flush=True)
            time.sleep(wait_time)
            delay = min(delay * 2, max_delay)
            attempt += 1

def fuzzy_llm_merge(corrupted_path, clean_path, output_path):
    with open(corrupted_path, 'r', encoding='utf-8') as f:
        corr_text = f.read()
    with open(clean_path, 'r', encoding='utf-8') as f:
        clean_text = f.read()
        
    client = genai.Client()
    paragraphs = clean_text.split('\n\n')
    batches = []
    current_batch = ""
    for p in paragraphs:
        if not p.strip(): continue
        if len(current_batch) + len(p) > 6000:
            batches.append(current_batch)
            current_batch = p
        else:
            current_batch += "\n\n" + p if current_batch else p
    if current_batch:
        batches.append(current_batch)

    aligned_chunks = []
    ratio = len(corr_text) / max(1, len(clean_text))
    current_clean_idx = 0
    
    for i, batch in enumerate(batches):
        if not batch.strip(): continue
        print(f"-> Processing batch {i+1}/{len(batches)} (Length: {len(batch)} chars)...", flush=True)
        
        current_clean_idx = clean_text.find(batch, current_clean_idx)
        start_est = max(0, int(current_clean_idx * ratio) - 2500)
        end_est = min(len(corr_text), int((current_clean_idx + len(batch)) * ratio) + 2500)
        corr_slice = corr_text[start_est:end_est]
        heuristic_slice = heuristic_cleanup(corr_slice)
        
        # ==========================================
        # PASS 1: The Formatter
        # ==========================================
        prompt_pass1 = f"""You are a strict, automated text alignment parser.
CRITICAL RULES:
1. NEVER converse or advise.
2. MATHEMATICAL FORMULAS: Convert broken math into standard LaTeX equations ($...$ or $$...$$).
3. TABLES AND HTML: You may use standard Markdown tables (`|---|`). You are ONLY allowed to use `<br>` tags to handle multiple lines in a table. You are STRICTLY FORBIDDEN from using `<b>`, `<u>`, `<i>`, `<ul>`, `<li>`, or `<p>`. Use pure Markdown formatting (`**bold**`, `*italics*`).
4. You MUST output your processed text strictly inside <aligned_text> and </aligned_text> XML tags.

<raw_corrupted_reference>
{corr_slice}
</raw_corrupted_reference>

<heuristic_reference>
{heuristic_slice}
</heuristic_reference>

<clean_ocr_text>
{batch}
</clean_ocr_text>
"""
        print("   [Pass 1] Generating Markdown formatting and tables...", flush=True)
        pass1_text = call_gemini_with_backoff(client, 'gemini-3.5-flash-lite', prompt_pass1)
        
        match_1 = re.search(r'<aligned_text>(.*?)</aligned_text>', pass1_text, re.DOTALL | re.IGNORECASE)
        clean_pass1 = match_1.group(1).strip() if match_1 else pass1_text.replace('```markdown', '').replace('```', '').strip()
        
        # ==========================================
        # PASS 2: The Sweeper
        # ==========================================
        prompt_pass2 = f"""You are an exact and literal proofreader. Your ONLY job is to prevent data loss.

Below is the ORIGINAL TEXT, and a FORMATTED TEXT version of it.
Sometimes the formatting process accidentally deletes sentences, footers, contact information, or orphaned paragraphs from the original text.

TASK:
1. Compare the ORIGINAL TEXT to the FORMATTED TEXT.
2. Find ANY valid text (like footers or emails) present in the ORIGINAL TEXT that is missing from the FORMATTED TEXT.
3. Output the exact FORMATTED TEXT as it is, but simply APPEND the missing text to the very bottom as a new paragraph.
4. DO NOT change the formatting of the existing FORMATTED TEXT. Just append what was lost.
5. You MUST output your final text strictly inside <final_text> and </final_text> XML tags.

<original_text>
{batch}
</original_text>

<formatted_text>
{clean_pass1}
</formatted_text>
"""
        print("   [Pass 2] Sweeping for deleted footers or missing text...", flush=True)
        pass2_text = call_gemini_with_backoff(client, 'gemini-3.5-flash-lite', prompt_pass2)
        
        match_2 = re.search(r'<final_text>(.*?)</final_text>', pass2_text, re.DOTALL | re.IGNORECASE)
        final_aligned = match_2.group(1).strip() if match_2 else pass2_text.replace('```markdown', '').replace('```', '').strip()

        aligned_chunks.append(final_aligned)
        time.sleep(10)
        
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(aligned_chunks))

if __name__ == "__main__":
    issue_num = sys.argv[1]
    corrupted_md = Path(f"conversions/issue-{issue_num}/corrupted/document/document.md")
    clean_md = Path(f"conversions/issue-{issue_num}/fixed/document/document.md")
    output_md = Path(f"conversions/issue-{issue_num}/document_aligned.md")
    if corrupted_md.exists() and clean_md.exists():
        fuzzy_llm_merge(corrupted_md, clean_md, output_md)
    else:
        sys.exit("❌ Missing input files.")
