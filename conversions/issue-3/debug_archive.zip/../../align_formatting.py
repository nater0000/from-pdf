import os
import random
import sys
import time
import re
from pathlib import Path
from google import genai

def heuristic_cleanup(text):
    text = text.replace('**', '∆∆').replace('*', '∆')
    chunks = re.split(r'( {2,}|\n+)', text)
    cleaned_chunks = []
    for chunk in chunks:
        if chunk.isspace():
            cleaned_chunks.append(chunk) 
        else:
            cleaned_chunk = re.sub(r'(?<=\S) (?=\S)', '', chunk)
            cleaned_chunks.append(cleaned_chunk)
    final_text = ''.join(cleaned_chunks)
    final_text = final_text.replace('∆∆', '**').replace('∆', '*')
    return final_text

def call_gemini_with_backoff(client, model, prompt, base_delay=5, max_delay=60, max_retries=30):
    delay = base_delay
    attempt = 1
    while True:
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt
            )
            return response.text
        except Exception as e:
            if attempt >= max_retries:
                print(f"\n❌ FATAL: Max retries ({max_retries}) reached.", flush=True)
                sys.exit(1)
            error_str = str(e)
            if '429' in error_str or 'RESOURCE_EXHAUSTED' in error_str:
                match = re.search(r'retry in ([\d\.]+)s', error_str, re.IGNORECASE)
                wait_time = float(match.group(1)) + 2.0 if match else 65.0
                print(f"🛑 Rate limit hit. Pausing {wait_time}s...", flush=True)
                time.sleep(wait_time)
                attempt += 1
                continue

            jitter = random.uniform(0.5, 2.0)
            wait_time = delay + jitter
            print(f"⚠️ API temporary error: {e}. Retrying in {wait_time:.1f}s...", flush=True)
            time.sleep(wait_time)
            delay = min(delay * 2, max_delay)
            attempt += 1

def fuzzy_llm_merge(corrupted_path, clean_path, output_path):
    with open(corrupted_path, 'r', encoding='utf-8') as f:
        corr_text = f.read()
    with open(clean_path, 'r', encoding='utf-8') as f:
        clean_text = f.read()
        
    client = genai.Client()
    paragraphs = clean_text.split('\n\n')
    batches = []
    current_batch = ""
    for p in paragraphs:
        if not p.strip(): continue
        if len(current_batch) + len(p) > 6000:
            batches.append(current_batch)
            current_batch = p
        else:
            current_batch += "\n\n" + p if current_batch else p
    if current_batch:
        batches.append(current_batch)

    aligned_chunks = []
    ratio = len(corr_text) / max(1, len(clean_text))
    current_clean_idx = 0
    
    for i, batch in enumerate(batches):
        if not batch.strip(): continue
        print(f"-> Processing batch {i+1}/{len(batches)} (Length: {len(batch)} chars)...", flush=True)
        
        current_clean_idx = clean_text.find(batch, current_clean_idx)
        start_est = max(0, int(current_clean_idx * ratio) - 2500)
        end_est = min(len(corr_text), int((current_clean_idx + len(batch)) * ratio) + 2500)
        corr_slice = corr_text[start_est:end_est]
        heuristic_slice = heuristic_cleanup(corr_slice)
        
        # ==========================================
        # STAGE 1: Formatter
        # ==========================================
        prompt_formatter = f"""You are a strict, automated text alignment parser.
CRITICAL RULES:
1. Apply Markdown formatting (**bold**, *italics*) to the CLEAN OCR TEXT.
2. MATHEMATICAL FORMULAS: Convert pseudo-LaTeX or broken math into clean standard LaTeX equations ($...$ or $$...$$).
3. TABLES: You may use standard Markdown tables (`|---|`) to map steps to timestamps. You are ONLY allowed to use `<br>` tags to handle multiple lines in a table cell. Do NOT use `<b>`, `<u>`, `<li>`, or `<p>`.
4. Output your formatted text inside <aligned_text> tags.

<raw_corrupted_reference>
{corr_slice}
</raw_corrupted_reference>

<heuristic_reference>
{heuristic_slice}
</heuristic_reference>

<clean_ocr_text>
{batch}
</clean_ocr_text>
"""
        print("   [Stage 1] Generating Formatted Markdown...", flush=True)
        formatter_text = call_gemini_with_backoff(client, 'gemini-3.5-flash-lite', prompt_formatter)
        match_1 = re.search(r'<aligned_text>(.*?)</aligned_text>', formatter_text, re.DOTALL | re.IGNORECASE)
        current_formatted = match_1.group(1).strip() if match_1 else formatter_text.replace('```markdown', '').replace('```', '').strip()
        
        # ==========================================
        # STAGE 2 & 3: The Audit Loop
        # ==========================================
        max_audit_loops = 3
        for audit_loop in range(max_audit_loops):
            time.sleep(5) # Pacing API
            print(f"   [Stage 2] Auditing for missing text (Pass {audit_loop+1}/{max_audit_loops})...", flush=True)
            
            prompt_auditor = f"""You are a strict QA Auditor. Your ONLY job is to find text from the ORIGINAL TEXT that was accidentally deleted or left out of the FORMATTED TEXT.
Pay special attention to footers, emails, URLs, and paragraphs at the end of the text.

TASK:
If you find ANY text in the ORIGINAL TEXT that is missing from the FORMATTED TEXT, output EXACTLY the missing text verbatim and nothing else.
If EVERYTHING from the ORIGINAL TEXT is present in the FORMATTED TEXT, output EXACTLY the word: COMPLETELY_ACCOUNTED_FOR

<original_text>
{batch}
</original_text>

<formatted_text>
{current_formatted}
</formatted_text>
"""
            missing_text_response = call_gemini_with_backoff(client, 'gemini-3.5-flash-lite', prompt_auditor).strip()
            
            if 'COMPLETELY_ACCOUNTED_FOR' in missing_text_response or len(missing_text_response) < 15:
                print("   ✅ Auditor confirmed all text is present.", flush=True)
                break
            else:
                print("   ⚠️ Auditor found missing text! Appending...", flush=True)
                time.sleep(5)
                
                prompt_appender = f"""You are a document recovery agent.
Take the FORMATTED TEXT below and append the MISSING TEXT to the very bottom as a new Markdown paragraph. 
Do NOT alter the FORMATTED TEXT. Keep the existing tables and formatting intact. Just append the missing information to the end.
Output the combined result inside <aligned_text> tags.

<formatted_text>
{current_formatted}
</formatted_text>

<missing_text>
{missing_text_response}
</missing_text>
"""
                appended_response = call_gemini_with_backoff(client, 'gemini-3.5-flash-lite', prompt_appender)
                match_3 = re.search(r'<aligned_text>(.*?)</aligned_text>', appended_response, re.DOTALL | re.IGNORECASE)
                if match_3:
                    current_formatted = match_3.group(1).strip()
                else:
                    # Fallback failsafe: literally string-append it if the LLM refuses to use tags
                    current_formatted = current_formatted + "\n\n" + missing_text_response.replace('```markdown', '').replace('```', '')

        aligned_chunks.append(current_formatted)
        time.sleep(5)
        
    print(f"-> Stitching and saving perfectly aligned markdown to: {output_path}", flush=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(aligned_chunks))

if __name__ == "__main__":
    issue_num = sys.argv[1]
    corrupted_md = Path(f"conversions/issue-{issue_num}/corrupted/document/document.md")
    clean_md = Path(f"conversions/issue-{issue_num}/fixed/document/document.md")
    output_md = Path(f"conversions/issue-{issue_num}/document_aligned.md")
    if corrupted_md.exists() and clean_md.exists():
        fuzzy_llm_merge(corrupted_md, clean_md, output_md)
    else:
        sys.exit("❌ Missing input files.")
